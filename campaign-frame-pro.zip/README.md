
# Profile Frame Generator

A high-performance web tool to create custom advocacy profile pictures.

## Features
- Real-time Canvas rendering.
- High-resolution (1024x1024) PNG output.
- Mobile-friendly responsive design.
- Instant download.

## Hosting on GitHub Pages

1. **Prepare for Deployment**:
   Ensure all files (`index.html`, `index.tsx`, `App.tsx`, etc.) are in your project root.

2. **GitHub Repository**:
   - Create a new repository on GitHub.
   - Push your code:
     ```bash
     git init
     git add .
     git commit -m "Initial commit"
     git remote add origin your-repo-url
     git push -u origin main
     ```

3. **Configure Pages**:
   - Go to your repository **Settings**.
   - Navigate to **Pages** in the left sidebar.
   - Under **Build and deployment**, set the source to **GitHub Actions** or **Deploy from a branch** (select `main` and `/ (root)`).
   - If using "Deploy from a branch", your site will be live at `https://yourusername.github.io/your-repo-name/`.

*Note: Since this app uses ESM modules and CDNs for React, it runs directly in modern browsers without a complex build step.*

## Customizing the Frame
To change the text or colors, open `App.tsx` and locate the `drawFrame` function. You can adjust the `ctx.fillStyle` and `ctx.fillText` calls to modify the branding.
