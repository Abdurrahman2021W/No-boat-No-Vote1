
import React from 'react';
import { SITE_NAME, TAGLINE } from '../constants.ts';

const Hero: React.FC = () => {
  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden bg-white">
      <div className="container mx-auto px-6 grid grid-cols-1 lg:grid-cols-12 gap-12 relative z-10">
        <div className="lg:col-span-12">
          <div className="mb-6 inline-block bg-black text-white px-4 py-1 font-bold text-sm tracking-widest uppercase">
            Official Advocacy Campaign
          </div>
          <h1 className="text-huge font-black tracking-tighter text-slate-950 mb-8 uppercase italic">
            {SITE_NAME}
          </h1>
          <div className="max-w-3xl">
            <p className="text-2xl md:text-3xl font-bold text-slate-700 leading-tight mb-10">
              {TAGLINE} We are fighting against the massive 400% increase in boat registration fees.
            </p>
            <div className="flex flex-col sm:flex-row gap-5">
              <a 
                href="#action" 
                className="px-10 py-5 bg-brand-red text-white text-xl font-black uppercase tracking-wider rounded-none hover:bg-black transition-all text-center"
              >
                Sign The Petition
              </a>
              <a 
                href="#issue" 
                className="px-10 py-5 border-4 border-black text-black text-xl font-black uppercase tracking-wider rounded-none hover:bg-black hover:text-white transition-all text-center"
              >
                Read The Facts
              </a>
            </div>
          </div>
        </div>
      </div>
      
      {/* Decorative vertical line */}
      <div className="absolute top-0 right-20 w-px h-full bg-slate-100 hidden lg:block"></div>
    </section>
  );
};

export default Hero;
